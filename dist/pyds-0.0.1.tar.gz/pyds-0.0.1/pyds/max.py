oldMax = max
from .flatten import *


def max(x):
    return oldMax(flatten(x))
