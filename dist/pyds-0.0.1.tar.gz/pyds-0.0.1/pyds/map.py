oldMap = map

def map(fn, arr):
  return list(oldMap(fn, arr))
