from .find_indexes import find_indexes


def find_indices(*args):
    return find_indexes(*args)
