from .find_indexes import findIndexes


def findIndices(*args):
    return findIndexes(*args)

