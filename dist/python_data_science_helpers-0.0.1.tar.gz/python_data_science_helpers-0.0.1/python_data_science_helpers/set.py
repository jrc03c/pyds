oldSet = set

def set(arr):
	return list(oldSet(arr))
