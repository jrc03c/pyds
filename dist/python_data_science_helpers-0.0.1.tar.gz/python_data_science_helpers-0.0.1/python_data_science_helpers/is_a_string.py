def isAString(x):
	return type(x) == str
