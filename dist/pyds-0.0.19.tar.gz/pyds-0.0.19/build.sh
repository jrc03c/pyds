echo "NOTE: Don't forget to update the version number in setup.py if you haven't already done so!"
python setup.py sdist