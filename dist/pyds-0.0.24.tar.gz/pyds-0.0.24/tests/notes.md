params to test:

- numbers
- strings
- booleans
- dictionaries
- arrays
  - lists
  - vectors
  - matrices
  - tensors
  - numpy `array` and `ndarray`
  - pandas `Series`
  - messy arrays that contain missing and/or non-numerical values
  - pandas `DataFrame`
- functions
- objects (instances of classes)
- None / NaN
