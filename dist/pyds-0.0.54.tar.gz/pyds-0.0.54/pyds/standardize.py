from .normalize import normalize


def standardize(*args, **kwargs):
    return normalize(*args, **kwargs)
