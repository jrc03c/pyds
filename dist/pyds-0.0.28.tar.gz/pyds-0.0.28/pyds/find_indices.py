from .find_indexes import *


def findIndices(*args):
    return findIndexes(*args)

