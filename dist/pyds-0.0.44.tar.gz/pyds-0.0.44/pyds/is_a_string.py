def is_a_string(x):
    return isinstance(x, str)
