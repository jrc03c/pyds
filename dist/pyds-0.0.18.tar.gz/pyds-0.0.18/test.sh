nosetests --nologcapture
