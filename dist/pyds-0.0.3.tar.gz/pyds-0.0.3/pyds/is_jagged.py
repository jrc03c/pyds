from .is_a_tensor import *
from .map import *
from .set import *


def isJagged(x):
    if not isATensor(x):
        return False

    childrenAreArrays = map(lambda item: isATensor(item), x)

    if len(set(childrenAreArrays)) > 1:
        return True

    if childrenAreArrays[0] == False:
        return False

    childLengths = map(lambda item: len(item), x)

    if len(set(childLengths)) > 1:
        return True

    childrenAreJagged = map(isJagged, x)

    if True in childrenAreJagged:
        return True

    return False

